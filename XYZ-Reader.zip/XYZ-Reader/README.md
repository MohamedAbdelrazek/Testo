# xyzreader

* A mock RSS feed reader featuring banner photos and shocking headlines!

* The app given initially is currently functional, and work in most cases for most users.

* The job will be to take the user feedback in the UI Review node below, and implement changes that will improve the UI and make it conform to Material Design.


## Screenshots

* MainActivity

![screen](../master/screen/Screenshot_20170418-170719.png)

* DetailActivity

![screen](../master/screen/Screenshot_20170418-170729.png)
## UI Review Node

* “This app is starting to shape up but it feels a bit off in quite a few places. I can't put finger on it but it feels odd.”

* “Is the text supposed to be so wonky and unreadable? It is not accessible to those of us without perfect vision."

* “The color scheme is really sad and I shouldn't feel sad.”
